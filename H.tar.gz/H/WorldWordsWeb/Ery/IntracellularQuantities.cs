﻿namespace Ery
{
    public class IntracellularQuantities
    {
        public double EpoR { get; set; }
        public double Caspaces { get; set; }
        public double Fas { get; set; }
        public double GlucoReceptor { get; set; }
        public double GataOne { get; set; }
    }
}