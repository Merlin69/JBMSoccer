﻿namespace Ery
{
    public class Position
    {
        private int Deep { get; set; }
        private int Horizontal { get; set; }
    }
}