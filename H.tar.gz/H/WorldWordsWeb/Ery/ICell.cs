﻿namespace Ery
{
    public interface ICell
    {
        decimal AgeForThisCycle { get; set; }
        decimal AgeTotal { get; set; }
        Position Position { get; set; }


        int NumberOfCycles { get; set; }
        int NumberOfCyclesMean { get; set; }
        IntracellularQuantities IntracellularQuantities { get; set; }

        void ActualizeCell();

        void ActualizeIntracellularQuantities();

        void Divide();
        void Die();
        void Differenciate();

        void Move(Position position);
    }
}