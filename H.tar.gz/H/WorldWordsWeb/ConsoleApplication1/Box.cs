﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    internal class c1

    {
        //public static void Main()
//        {
//
//            var box = new Box<int>(){1,2,3};
//            var boxN = new Box<string>(){"e"};
//            var f = box.First();
//            Console.WriteLine(f);
//            Console.ReadKey();
//        }

        public class Box<T> : IEnumerable<T>, IEnumerable
        {
            private HashSet<T> _box = new HashSet<T>();
            private T current;

            public void Print(string s)
            {
                Console.WriteLine(s);
            }

            public void Add(T t)
            {
                _box.Add(t);
            }

            public IEnumerator<T> GetEnumerator()
            {
                Console.WriteLine("T called");
                return _box.GetEnumerator();
            }

            IEnumerator IEnumerable.GetEnumerator()
            {
                Console.WriteLine("normal called");
                return GetEnumerator();
            }
        }
    }
}