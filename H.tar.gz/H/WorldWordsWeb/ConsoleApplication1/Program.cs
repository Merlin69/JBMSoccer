﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    public class String
    {
        public void test()
        {
            var newdc = new Program();
            Program.Delr = teste;
        }

        public void teste()
        {
            
        }
    }
    internal class Program
    {
        //alle rplus loin avec la mémoire etc, relier a la "perte de mémoire" ?
        // regarder si on peut faire la meme chose avec un delegate ?

        public static Del Delr;
        public delegate void Del();

        public Dele BoDele;
        public delegate User Dele(int i);

        public static event Action Raise = delegate {Console.WriteLine("raised"); };
        private static event Action Coucou;

        protected static void Subscribe(Action bobAction)
        {
            Coucou += bobAction;
        }

        protected static void UnSubscribe(Action bobAction)
        {
            Coucou -= bobAction;
        }

        protected static void OnCoucou()
        {
            Action handler = Coucou;
            if (handler != null) handler();
        }

        public delegate void Visitor(int i);

        public static void ApplyToList(Action<int> func)
        {
            var list = new List<int> {1, 5, 3};
            foreach (var element in list)
            {
                func(element);
            }
        }

        public static void Traitement1(int i)
        {
            Raise();
        }

        public static void PrintR()
        {
            Console.WriteLine("R");
        }

        public static void Traitement2(int i)
        {
            if (i > 5)
            {
                OnCoucou();
            }
        }

        public static void PrintI(int i)
        {
            Console.WriteLine("printI " + i);
        }

        public static User Test1(int i)
        {
            var gerard = new User();
            Console.WriteLine("test1.prenom" + gerard.Prenom);
            Console.WriteLine("test1.number" + gerard.Number);
            return gerard;
        }

        public User Test2(int i)
        {
            var gerard = new User();
            Console.WriteLine("test2.prenom" + gerard.Prenom);
            Console.WriteLine("test2.number" + gerard.Number);
            return gerard;
        }


//        private static void Main(string[] args)
//        {
//            String dc=new String();
//            Console.WriteLine(dc);
//
//            var myDel = new Dele(Test1);
//
//            myDel(5);
//            myDel(7);
//            Test1(8);
//
//            var visitor = new Visitor(PrintI);
//
//            ApplyToList(PrintI);
//            ApplyToList(delegate(int i) { Console.WriteLine(i + 2); });
//
////            Coucou += PrintR;
////            Coucou += PrintR;
////            Raise += PrintR;
////
////            
////
//            Traitement1(3); //raise
//            Traitement2(40); //oncoucou empty
//
//            Subscribe(PrintR);
//
//            Traitement2(40); //oncoucou R
//            Coucou=PrintR;
//            Coucou=PrintR;
//            Coucou=PrintR;
//
//            UnSubscribe(PrintR);
//
//            Traitement2(40); //oncoucou R
//
//            Console.WriteLine();
//            Console.ReadKey();
//        }
    }

    public class User
    {
        public int Number { get; set; }
        public string Prenom { get; set; }
    }
}