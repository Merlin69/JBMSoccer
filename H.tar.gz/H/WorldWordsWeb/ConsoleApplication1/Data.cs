﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace ConsoleApplication1
{
    internal class Data
    {
        public static void Main()
        {
            var matches = new List<Match>();

            string[] output = File.ReadAllLines(@"C:\Users\merlin legrain\Desktop\countries.txt");


            var match = new Match();

            foreach (string line in output)
            {
                int n;
                if (line != null
                    && line.Length >= 6
                    && int.TryParse(line[0].ToString() + line[1] + line[2] + line[3] + line[4], out n)
                    && line[5].ToString() == ".")
                {
                    if (match.total != null && match.total != string.Empty)
                    {
                        matches.Add(match);
                    }

                    match = new Match();
                    match.total += line;
                }
                else
                {
                    match.total += "\t" + line;
                }
            }

            foreach (Match matchM in matches)
            {
                int n;
                string line = matchM.total;
                if (int.TryParse(line[0].ToString() + line[1] + line[2] + line[3] + line[4], out n))
                {
                    matchM.number = n;
                }

                var List = new List<int>();
                bool isBeforeTab = false;
                int iterator = 0;
                foreach (char chara in line)
                {
                    if (chara == '\t' && isBeforeTab)
                    {
                        List.Add(iterator);
                    }
                    else if (chara == '\t')
                    {
                        isBeforeTab = true;
                    }
                    else
                    {
                        isBeforeTab = false;
                    }
                    iterator++;
                }
                List<char> linelist = line.ToList();
                foreach (int i in List)
                {
                    linelist[i] = '_';
                }

                line = string.Empty;
                foreach (char v in linelist)
                {
                    if (v != '_' && v != '*')
                    {
                        line += v;
                    }
                    
                }

                string[] splited = line.Split('\t');

                if (splited.Length < 7 || splited.Length > 7)
                {
                    Console.WriteLine("BUG");
                    Console.WriteLine(line);
                }

                matchM.date = splited[1];
                matchM.equipe1 = splited[4];
                matchM.equipe2 = splited[6];
                var score1 = splited[5].Split(':')[0].ToString();
                var score2 = splited[5].Split(':')[1].ToString();
                matchM.score1 = score1;
                matchM.score2 = score2;
            }

            System.IO.StreamWriter file = new System.IO.StreamWriter(@"C:\Users\merlin legrain\Desktop\data.txt");
            
            foreach (var match1 in matches)
            {
                file.WriteLine(match1.ToString());
            }

            file.Close();

            var hash = new HashSet<string>();
            foreach (var match1 in matches)
            {
                hash.Add(match1.equipe1);
                hash.Add(match1.equipe2);
            }

            var hash2=hash.OrderByDescending(pet => pet);
            System.IO.StreamWriter file2 = new System.IO.StreamWriter(@"C:\Users\merlin legrain\Desktop\countrynames.txt");

            foreach (var team in hash2)
            {
                file2.WriteLine(team);
            }

            file2.Close();



            Console.WriteLine(matches[5].total);
            Console.WriteLine(matches[5].date);
            Console.WriteLine(matches.Count);
            Console.Read();
        }

        public class Match
        {
            public string total { get; set; }
            public int number { get; set; }
            public string date { get; set; }
            public string equipe1 { get; set; }
            public string equipe2 { get; set; }
            public string score1 { get; set; }
            public string score2 { get; set; }

            public override string ToString()
            {
                return equipe1 + "," + equipe2 + "," + score1 + "," + score2 + "," + date;
            }
        }
    }
}