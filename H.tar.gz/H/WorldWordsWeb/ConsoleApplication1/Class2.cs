﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Class2
    {
        public class C<T>
        {
            private T _current;
            private int bob;
            private string bobi;

            public C()
            {
            }

            public C(T current)
            {
                this._current = current;
            }

            public void Print()
            {
                if (typeof (T) == typeof(int))
                {
                    bob++;
                    Console.WriteLine(bob);
                }
                else
                {
                    bobi += "gaga" + null;
                    Console.WriteLine(bobi);
                }
                
            }
        }

        //public static void Main()
//        {
//
//            var c = new C<int>(5);
//            var c2 = new C<string>("bob");
//
//            c.Print();
//            c2.Print();
//
//            Console.WriteLine(typeof(Int64));
//            Console.ReadKey();
//
//        }
    }
}
