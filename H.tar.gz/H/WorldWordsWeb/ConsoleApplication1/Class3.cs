﻿using System;
using System.Collections.Generic;

namespace ConsoleApplication1
{
    internal class MyGCCollectClass
    {
        private const int maxGarbage = 1000;

        /*private static void Main()
        {
            var test = new List<string>();
            var a = new ListMerlin();
            a.clear(ref test);
            a.Add("bob");
            a.Add("ij");
            a.change(1, "gerard");
            a.modify(0,"rer");

            //a.list.Clear();

            foreach (string VARIABLE in a.list)
            {
                Console.WriteLine(VARIABLE);
            }

            foreach (string VARIABLE in test)
            {
                Console.WriteLine(VARIABLE);
            }

            Console.ReadKey();
        }
         * */

        private static void MakeSomeGarbage()
        {
        }

        public class ListMerlin
        {
            public readonly List<string> list = new List<string>();

            char[] buffer = new char[128];

            public void Add(string s)
            {
                list.Add(s);
            }

            public void change(int index, string s)
            {
                list[index] = s;
            }

            public void modify(int index, string s)
            {
                list[index] = list[index] + s;
            }

            public void clear(ref List<string> copy)
            {
                copy = list;
            }

        }
    }
}