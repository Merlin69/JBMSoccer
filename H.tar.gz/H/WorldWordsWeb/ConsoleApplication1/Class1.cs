﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    public sealed class Singleton
    {
        private static Singleton instance;
        private readonly static object toLock=new object();

        private Singleton()
        {
        }

        public static Singleton Instance
        {
            
            get
            {
                lock (toLock)
                {


                    if (instance == null)
                    {
                        instance = new Singleton();
                    }

                    return
                        instance;
                }
            }
        }
    }

    public static class B
    {
        static B()
        {
        }
    }

    internal class Class1
    {
        public class A
        {
            public string bob = "uh";
            public int ik = 5;
            public readonly List<B> li = new List<B> {new B(), new B(), new B(), new B(), new B()};

            public void metho()
            {
                Console.WriteLine("AA");
            }
        }

        public class B
        {
            public void metho()
            {
                Console.WriteLine("BB");
            }
        }

        public static void modify(A a)
        {
            a.ik++;
            a.bob = "r";
            //a.li.Clear();
            //a.li.Add(new B());

            //a=new A();
        }
        public class C
        {
            public int i = 1;
            
        }
        public interface AZ
        {
            int i {get;set;}

        }

        //private static void Main(string[] args)
//        {
//            int aa=5;
//            if (aa != 0)
//            {
//                Console.WriteLine(aa);
//            }
//
//            List<int> l = new List<int> { 1, 2 };
//            string bobed = "bob";
//            Console.WriteLine(l.Count);
//            Console.WriteLine(bobed.Length);
//            var c = new C();
//            var b = new B();
//            b.metho();
//            var a = new A();
//            modify(a);
//            Console.WriteLine(a.ik);
//            Console.WriteLine(a.bob);
//            Console.WriteLine(a.li[1]);
//            Console.ReadKey();
//        }
    }
}