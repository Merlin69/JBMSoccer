﻿using System;
using System.Collections.Generic;
using System.IO;

namespace WorldWordsWeb
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            var myFile = new StreamReader(@"C:\Users\merlin legrain\Desktop\Merlin Legrain - HowToWork @MargoConseil\Perso\WorldWordsWeb\ListeMotFr.txt");
            string myString = myFile.ReadToEnd();
            myFile.Close();

            var Dict = new FileCounting();
            Dict.ActualizeVars(myString);

            Console.WriteLine(Dict.WordSum);
            Console.WriteLine(Dict.CountByWordLenght[0]);
            Console.WriteLine(Dict.CountByWordLenght[1]);
            Console.WriteLine(Dict.CountByWordLenght[2]);
            Console.WriteLine(Dict.CountByWordLenght[3]);
            Console.WriteLine(Dict.CountByWordLenght[4]);

            var urls = new Urls().UrlsFile;
            new FilesManager(urls).ManageFiles(Dict.Dico);

            Console.ReadLine();
        }

        
    }
}