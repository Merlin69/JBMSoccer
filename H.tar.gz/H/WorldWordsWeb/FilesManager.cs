﻿using System;
using System.Collections.Generic;
using System.IO;

namespace WorldWordsWeb
{
    public class FilesManager
    {
        private decimal[] ScoreComparedToFrenchDict { get; set; }
        private decimal[] Diff { get; set; }
        private List<string> Urls { get; set; }
        private FileCounting[] Liste { get; set; }

        public FilesManager(List<string> urls)
        {
            Diff = new decimal[urls.Count];
            Liste = new FileCounting[urls.Count];
            ScoreComparedToFrenchDict = new decimal[urls.Count];
            Urls = urls;
        }


        public void ManageFiles(Dictionary<string,int> dictionary)
        {
            int iterator = 0;
            foreach (string url in Urls)
            {
                var myFile = new StreamReader(url);
                string myString = myFile.ReadToEnd();
                myFile.Close();

                var ope = new FileCounting();
                Liste[iterator] = ope;
                ope.ActualizeVars(myString);


                for (int i = 0; i < ope.CountByWordLenght.Length; i++)
                {
                    Diff[iterator] += (Liste[0].CountByWordLenght[i] - Liste[iterator].CountByWordLenght[i])*
                                      (Liste[0].CountByWordLenght[i] - Liste[iterator].CountByWordLenght[i])*
                                      Liste[0].CountByWordLenght[i]*100000;
                }

                ScoreComparedToFrenchDict[iterator] = ope.CompareToDict(dictionary);

                Console.WriteLine(Diff[iterator]);
                Console.WriteLine(ScoreComparedToFrenchDict[iterator]);
                Console.WriteLine("------------");

                iterator++;
            }


        }
    }
}