﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestsMerlin
{
    public class Class1
    {
        public delegate void Del();

        public void Print()
        {
            Console.WriteLine("bob");
        }

        public void Main()
        {
            var c1 = new Class1();
            c1.Print();
        }
    }
}


