﻿using System.Collections.Generic;
using WorldWordsWeb;

namespace FrenchDico
{
    public class FrenchDict
    {
        public FrenchDict()
        {
            var bob = new FileCounting();
            Dict = bob.Dico;
        }

        public Dictionary<string, int> Dict { get; set; }
    }
}