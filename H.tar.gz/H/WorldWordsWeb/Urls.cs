﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WorldWordsWeb
{
    public class Urls
    {
        public List<string> UrlsFile { get; private set; }

        public Urls()
        {
            UrlsFile = new List<string>()
            {
                @"C:\Users\merlin legrain\Desktop\Merlin Legrain - HowToWork @MargoConseil\Perso\WorldWordsWeb\20000.txt",
                @"C:\Users\merlin legrain\Desktop\Merlin Legrain - HowToWork @MargoConseil\Perso\WorldWordsWeb\comte_jules_verne.txt",
                @"C:\Users\merlin legrain\Desktop\Merlin Legrain - HowToWork @MargoConseil\Perso\WorldWordsWeb\chancellor_jules_verne.txt",
                @"C:\Users\merlin legrain\Desktop\Merlin Legrain - HowToWork @MargoConseil\Perso\WorldWordsWeb\terre_lune_jules_verne.txt",
                @"C:\Users\merlin legrain\Desktop\Merlin Legrain - HowToWork @MargoConseil\Perso\WorldWordsWeb\balzac.txt"
            };
        }
            
    }
}
