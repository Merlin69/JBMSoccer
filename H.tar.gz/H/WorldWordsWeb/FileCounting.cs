using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace WorldWordsWeb
{
    public class FileCounting
    {
        private const string Letters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
        public int WordSum { get; private set; }

        public decimal[] CountByWordLenght { get; private set; }
        public Dictionary<string, int> Dico { get; private set; }

        public void ActualizeVars(string s)
        {
            CountByWordLenght = new decimal[128];
            Dico = new Dictionary<string, int>();

            int length = s.Length;
            int countWord = 0;
            string word = string.Empty;

            for (int n = length - 1; n >= 0; n--)
            {
                if (Letters.Contains(s[n].ToString(CultureInfo.InvariantCulture)))
                {
                    countWord++;
                    word += s[n];
                }
                else
                {
                    if (countWord > 0)
                    {
                        CountByWordLenght[countWord - 1]++;
                        if (Dico.ContainsKey(word))
                        {
                            Dico[word]++;
                        }
                        else
                        {
                            Dico.Add(word, 1);
                        }
                    }
                    countWord = 0;
                    word = string.Empty;
                }
            }

            WordSum = (int)CountByWordLenght.Sum();
            for (int i = 0; i < CountByWordLenght.Length; i++)
            {
                CountByWordLenght[i] /= WordSum;
            }
        }

        public decimal CompareToDict(Dictionary<string, int> dictionary)
        {
            decimal result=0;

            foreach (var key in Dico.Keys)
            {
                if (dictionary.ContainsKey(key))
                {
                    result++;
                }
                else
                {
                    Console.WriteLine(key);
                }
            }

            return result/Dico.Count;
        }
    }
}